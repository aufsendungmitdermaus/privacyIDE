
.. _hotp_token_config:

HOTP Token Config
.................

.. index:: HOTP Token

.. figure:: images/hotp.png
   :width: 500

   *HOTP Token configuration*
