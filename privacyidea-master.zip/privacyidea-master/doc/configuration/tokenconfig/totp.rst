
.. _totp_token_config:

TOTP Token Config
.................

.. index:: TOTP Token

.. figure:: images/totp.png
   :width: 500

   *TOTP Token configuration*
