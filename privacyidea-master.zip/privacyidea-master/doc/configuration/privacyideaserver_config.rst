.. _privacyideaserver_config:

privacyIDEA server configuration
--------------------------------

.. index:: privacyIDEA server

At *config->system->privacyIDEA servers* the administrator
can configure a remote privacyIDEA servers.
These can be used in the :ref:`remote_token`
or in the :ref:`federationhandler` to forward the authentication request to.



