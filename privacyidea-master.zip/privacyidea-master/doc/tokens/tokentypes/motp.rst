.. _motp_token:

mOTP Token
---------

mOTP is a time based One Time Password token for mobile phones based on a
`public Algorithm <http://motp.sourceforge.net>`_.