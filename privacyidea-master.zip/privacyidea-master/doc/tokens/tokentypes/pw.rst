.. _pw_token:

Password Token
---------

This token is not enrolled by the user. It is automatically created whenever an
authorized user initiates a :ref:`lost_token` scenario.