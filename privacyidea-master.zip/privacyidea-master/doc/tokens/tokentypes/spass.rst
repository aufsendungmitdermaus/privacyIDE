.. _spass_token:

Spass - Simple Pass Token
-------------------------

.. index:: SPass token

The OTP component of the *spass* token is always true. Thus the user only
needs to provide the OTP pin or the userstore password - depending on the
policy settings.

For a more detailed insight see the code documentation :ref:`code_spass_token`.
