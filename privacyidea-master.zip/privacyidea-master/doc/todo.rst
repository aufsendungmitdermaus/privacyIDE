:orphan:

.. _todolist:

To Do List
------

You may enable the display of to do items by using::

   make htmltodo

This uses the `sphinx.ext.todo <https://www.sphinx-doc.org/en/master/usage/extensions/todo.html>`_ extension.

.. todolist::
