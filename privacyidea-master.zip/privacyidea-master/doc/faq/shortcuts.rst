Are there shortcuts to use the Web UI?
--------------------------------------

.. index:: shortcuts, hotkeys

I do not like using the mouse. Are there hotkeys or shortcuts to use the Web UI?

With version 2.6 we started to add hotkeys to certain functions. You can use
``?`` to get a list of the available hotkeys in the current window.

E.g. you can use ``alt-e`` to go to the *Enroll Token* Dialog and ``alt-r`` to
actually enroll the token.

For any further ideas about shortcuts/hotkeys please drop us a note at
`GitHub <https://github.com/privacyidea/privacyidea>`_.
