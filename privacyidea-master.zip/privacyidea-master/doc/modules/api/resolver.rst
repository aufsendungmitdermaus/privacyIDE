.. _rest_resolver:

Resolver endpoints
~~~~~~~~~~~~~~~~~~

.. use the docstring from the module file
.. automodule:: privacyidea.api.resolver


.. autoflask:: privacyidea.app:create_app()
   :endpoints:
   :blueprints: resolver_blueprint

   :include-empty-docstring:

