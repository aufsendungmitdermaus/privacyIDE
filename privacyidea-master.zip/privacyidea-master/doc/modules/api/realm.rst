.. _rest_realm:

Realm endpoints
~~~~~~~~~~~~~~~

.. use the docstring from the module file
.. automodule:: privacyidea.api.realm

.. autoflask:: privacyidea.app:create_app()
   :endpoints:
   :blueprints: realm_blueprint

   :include-empty-docstring:

