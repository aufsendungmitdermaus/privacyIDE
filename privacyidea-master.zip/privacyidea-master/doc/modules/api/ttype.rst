.. _rest_ttype:

Tokentype endpoints
~~~~~~~~~~~~~~~~~~~

.. automodule:: privacyidea.api.ttype

.. autoflask:: privacyidea.app:create_app()
   :endpoints:
   :blueprints: ttype_blueprint

   :include-empty-docstring:
