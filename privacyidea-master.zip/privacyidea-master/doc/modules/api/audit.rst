.. use the docstring from the module file
.. automodule:: privacyidea.api.auth

.. _rest_audit:

Audit endpoint
..............

.. autoflask:: privacyidea.app:create_app()
   :endpoints:
   :blueprints: audit_blueprint

   :include-empty-docstring:

