.. _rest_smtpserver:

SMTP server endpoints
.....................

.. automodule:: privacyidea.api.smtpserver

.. autoflask:: privacyidea.app:create_app()
   :endpoints:
   :blueprints: smtpserver_blueprint

   :include-empty-docstring:

