.. _rest_subscriptions:

Subscriptions endpoints
.......................

.. automodule:: privacyidea.api.subscriptions

.. autoflask:: privacyidea.app:create_app()
   :endpoints:
   :blueprints: subscriptions_blueprint

   :include-empty-docstring:

