.. _rest_recover:

Recover endpoints
.................

.. automodule:: privacyidea.api.recover

.. autoflask:: privacyidea.app:create_app()
   :endpoints:
   :blueprints: recover_blueprint

   :include-empty-docstring:

