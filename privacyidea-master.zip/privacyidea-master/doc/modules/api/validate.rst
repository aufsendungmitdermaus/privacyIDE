.. _rest_validate:

Validate endpoints
~~~~~~~~~~~~~~~~~~

.. automodule:: privacyidea.api.validate

.. autoflask:: privacyidea.app:create_app()
   :endpoints:
   :blueprints: validate_blueprint

   :include-empty-docstring:
