.. _rest_serviceid:

Service ID endpoints
~~~~~~~~~~~~~~~~~~~~

.. use the docstring from the module file
.. automodule:: privacyidea.api.serviceid


.. autoflask:: privacyidea.app:create_app()
   :endpoints:
   :blueprints: serviceid_blueprint

   :include-empty-docstring:

