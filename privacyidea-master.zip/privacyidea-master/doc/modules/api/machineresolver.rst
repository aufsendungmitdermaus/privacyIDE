.. _rest_machineresolver:

.. use the docstring from the module file
.. automodule:: privacyidea.api.machineresolver

Machine Resolver endpoints
~~~~~~~~~~~~~~~~~~~~~~~~~~

.. autoflask:: privacyidea.app:create_app()
   :endpoints:
   :blueprints: machineresolver_blueprint

   :include-empty-docstring:

