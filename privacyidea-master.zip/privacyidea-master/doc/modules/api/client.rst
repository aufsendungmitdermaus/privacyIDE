.. _rest_client:

Client endpoints
................

.. automodule:: privacyidea.api.clienttype

.. autoflask:: privacyidea.app:create_app()
   :endpoints:
   :blueprints: client_blueprint

   :include-empty-docstring: