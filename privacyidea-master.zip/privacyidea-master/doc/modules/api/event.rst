.. _rest_event:

Event endpoints
...............

.. automodule:: privacyidea.api.event

.. autoflask:: privacyidea.app:create_app()
   :endpoints:
   :blueprints: eventhandling_blueprint

   :include-empty-docstring:

