.. _rest_periodictask:

Periodic Task endpoints
.......................

.. automodule:: privacyidea.api.periodictask

.. autoflask:: privacyidea.app:create_app()
   :endpoints:
   :blueprints: periodictask_blueprint

   :include-empty-docstring:
