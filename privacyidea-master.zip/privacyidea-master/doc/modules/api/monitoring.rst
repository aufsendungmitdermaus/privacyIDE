.. _rest_monitoring:

Monitoring endpoints
....................

.. automodule:: privacyidea.api.monitoring

.. autoflask:: privacyidea.app:create_app()
   :endpoints:
   :blueprints: monitoring_blueprint

   :include-empty-docstring:

