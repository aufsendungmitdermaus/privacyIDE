.. _rest_smsgateway:

SMS Gateway endpoints
.....................

.. automodule:: privacyidea.api.smsgateway

.. autoflask:: privacyidea.app:create_app()
   :endpoints:
   :blueprints: smsgateway_blueprint

   :include-empty-docstring:

