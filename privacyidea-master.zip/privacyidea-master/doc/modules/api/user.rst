.. _rest_user:

.. automodule:: privacyidea.api.user

User endpoints
~~~~~~~~~~~~~~
The user endpoints is a subset of the system endpoint.

.. autoflask:: privacyidea.app:create_app()
   :endpoints:
   :blueprints: user_blueprint

   :include-empty-docstring:

