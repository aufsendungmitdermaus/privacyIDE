.. _rest_register:

Register endpoints
..................

.. automodule:: privacyidea.api.register

.. autoflask:: privacyidea.app:create_app()
   :endpoints:
   :blueprints: register_blueprint

   :include-empty-docstring:

