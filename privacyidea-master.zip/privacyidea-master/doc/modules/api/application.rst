.. _rest_application:

.. use the docstring from the module file
.. automodule:: privacyidea.api.application

Application endpoints
.....................

.. autoflask:: privacyidea.app:create_app()
   :endpoints:
   :blueprints: application_blueprint

   :include-empty-docstring:
