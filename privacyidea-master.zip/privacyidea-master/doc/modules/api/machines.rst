.. _rest_machine:

Machine endpoints
~~~~~~~~~~~~~~~~~

.. automodule:: privacyidea.api.machine

.. autoflask:: privacyidea.app:create_app()
   :endpoints:
   :blueprints: machine_blueprint

   :include-empty-docstring:

