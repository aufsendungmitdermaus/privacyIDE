.. _rest_privacyideaserver:

privacyIDEA Server endpoints
............................

.. automodule:: privacyidea.api.privacyideaserver

.. autoflask:: privacyidea.app:create_app()
   :endpoints:
   :blueprints: privacyideaserver_blueprint

   :include-empty-docstring:

