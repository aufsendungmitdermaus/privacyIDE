.. _rest_tokengroup:

Tokengroup endpoints
~~~~~~~~~~~~~~~~~~~~

.. use the docstring from the module file
.. automodule:: privacyidea.api.tokengroup


.. autoflask:: privacyidea.app:create_app()
   :endpoints:
   :blueprints: tokengroup_blueprint

   :include-empty-docstring:

