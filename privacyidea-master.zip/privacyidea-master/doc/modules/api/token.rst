.. _rest_token:

Token endpoints
...............

.. automodule:: privacyidea.api.token

.. autoflask:: privacyidea.app:create_app()
   :endpoints:
   :blueprints: token_blueprint

   :include-empty-docstring:
