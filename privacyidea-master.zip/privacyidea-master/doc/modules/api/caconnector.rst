.. _rest_caconnector:

CA Connector endpoints
......................

.. automodule:: privacyidea.api.caconnector

.. autoflask:: privacyidea.app:create_app()
   :endpoints:
   :blueprints: caconnector_blueprint

   :include-empty-docstring:

