.. _rest_system:

System endpoints
................

.. automodule:: privacyidea.api.system

.. autoflask:: privacyidea.app:create_app()
   :endpoints:
   :blueprints: system_blueprint

   :include-empty-docstring:

