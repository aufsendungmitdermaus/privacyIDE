.. _rest_radiusserver:

RADIUS server endpoints
.......................

.. automodule:: privacyidea.api.radiusserver

.. autoflask:: privacyidea.app:create_app()
   :endpoints:
   :blueprints: radiusserver_blueprint

   :include-empty-docstring:

