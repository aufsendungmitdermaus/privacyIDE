.. _code_job_queue:

Job Queue
.........

The following queue classes are known to privacyIDEA

.. toctree::
   :glob:

   queueclasses/*

.. automodule:: privacyidea.lib.queue
   :members:
   :undoc-members:

Base class
~~~~~~~~~~


.. autoclass:: privacyidea.lib.queues.base.BaseQueue
   :members:
   :undoc-members:

