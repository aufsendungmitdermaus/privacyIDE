.. _code_event_handler_user_notification:

User Notification Event Handler
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. index:: User Notification, Event Handler

.. autoclass:: privacyidea.lib.eventhandler.usernotification.UserNotificationEventHandler
   :members:
   :undoc-members:
