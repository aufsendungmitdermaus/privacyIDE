.. _code_event_handler:

Event Handler Base Class
~~~~~~~~~~~~~~~~~~~~~~~~

.. autoclass:: privacyidea.lib.eventhandler.base.BaseEventHandler
   :members:
   :undoc-members:
