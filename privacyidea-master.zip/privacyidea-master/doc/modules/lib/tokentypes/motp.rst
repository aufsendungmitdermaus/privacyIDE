.. _code_motp_token:

mOTP Token
~~~~~~~~~~

.. autoclass:: privacyidea.lib.tokens.motptoken.MotpTokenClass
   :members:
   :undoc-members:
