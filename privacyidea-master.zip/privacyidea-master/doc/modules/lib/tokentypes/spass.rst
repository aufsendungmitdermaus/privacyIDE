.. _code_spass_token:

SPass Token
~~~~~~~~~~~

.. autoclass:: privacyidea.lib.tokens.spasstoken.SpassTokenClass
   :members:
   :undoc-members:
