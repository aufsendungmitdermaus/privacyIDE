.. _code_paper_token:

Paper Token
~~~~~~~~~~~

.. autoclass:: privacyidea.lib.tokens.papertoken.PaperTokenClass
   :members:
   :undoc-members:
