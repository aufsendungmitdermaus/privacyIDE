.. _code_push_token:

Push Token
~~~~~~~~~~

.. autoclass:: privacyidea.lib.tokens.pushtoken.PushTokenClass
   :members:
   :undoc-members:
