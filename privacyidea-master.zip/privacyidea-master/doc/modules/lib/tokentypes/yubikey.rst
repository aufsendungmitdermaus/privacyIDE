.. _code_yubikey_token:

Yubikey Token
~~~~~~~~~~~~~

.. autoclass:: privacyidea.lib.tokens.yubikeytoken.YubikeyTokenClass
   :members:
   :undoc-members:
