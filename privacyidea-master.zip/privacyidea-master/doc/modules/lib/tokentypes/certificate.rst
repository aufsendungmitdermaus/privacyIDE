.. _code_certifiacte_token:

Certificate Token
~~~~~~~~~~~~~~~~~

.. autoclass:: privacyidea.lib.tokens.certificatetoken.CertificateTokenClass
   :members:
   :undoc-members:
