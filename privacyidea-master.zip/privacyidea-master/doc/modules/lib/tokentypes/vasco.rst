.. _code_vasco_token:

Vasco Token
~~~~~~~~~~~

.. autoclass:: privacyidea.lib.tokens.vascotoken.class VascoTokenClass
   :members:
   :undoc-members:
