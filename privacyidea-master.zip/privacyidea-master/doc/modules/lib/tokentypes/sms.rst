.. _code_sms_token:

SMS Token
~~~~~~~~~

.. autoclass:: privacyidea.lib.tokens.smstoken.SmsTokenClass
   :members:
   :undoc-members:
