.. _code_hotp_token:

HOTP Token
~~~~~~~~~~

.. autoclass:: privacyidea.lib.tokens.hotptoken.HotpTokenClass
   :members:
   :undoc-members:
