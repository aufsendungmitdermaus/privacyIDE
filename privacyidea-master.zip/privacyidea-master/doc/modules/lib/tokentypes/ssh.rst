.. _code_ssh_token:

SSHKey Token
~~~~~~~~~~~~

.. autoclass:: privacyidea.lib.tokens.sshkeytoken.SSHkeyTokenClass
   :members:
   :undoc-members:
