.. _code_remote_token:

Remote Token
~~~~~~~~~~~~

.. autoclass:: privacyidea.lib.tokens.remotetoken.RemoteTokenClass
   :members:
   :undoc-members:
