.. _code_email_token:

Email Token
~~~~~~~~~~~

.. autoclass:: privacyidea.lib.tokens.emailtoken.EmailTokenClass
   :members:
   :undoc-members:
