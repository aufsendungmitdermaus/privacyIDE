.. _code_u2f_token:

U2F Token
~~~~~~~~~

.. automodule:: privacyidea.lib.tokens.u2ftoken

Implementation
..............

.. autoclass:: privacyidea.lib.tokens.u2ftoken.U2fTokenClass
   :members:
   :undoc-members:
