.. _code_ocra_token:

OCRA Token
~~~~~~~~~~

.. automodule:: privacyidea.lib.tokens.ocratoken

Implementation
..............

.. autoclass:: privacyidea.lib.tokens.ocratoken.OcraTokenClass
   :members:
   :undoc-members:
