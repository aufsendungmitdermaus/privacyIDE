.. _code_yubico_token:

Yubico Token
~~~~~~~~~~~~

.. autoclass:: privacyidea.lib.tokens.yubicotoken.YubicoTokenClass
   :members:
   :undoc-members:
