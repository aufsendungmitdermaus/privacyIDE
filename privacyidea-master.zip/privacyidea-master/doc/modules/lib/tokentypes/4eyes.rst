.. _code_foureye_token:

4 Eyes Token
~~~~~~~~~~~~

.. autoclass:: privacyidea.lib.tokens.foureyestoken.FourEyesTokenClass
   :members:
   :undoc-members:
