.. _code_password_token:

PasswordToken
~~~~~~~~~~~~~

.. autoclass:: privacyidea.lib.tokens.passwordtoken.PasswordTokenClass
   :members:
   :undoc-members:
