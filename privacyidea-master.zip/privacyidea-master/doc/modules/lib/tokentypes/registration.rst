.. _code_registration_token:

Registration Code Token
~~~~~~~~~~~~~~~~~~~~~~~

.. autoclass:: privacyidea.lib.tokens.registrationtoken.RegistrationTokenClass
   :members:
   :undoc-members:
