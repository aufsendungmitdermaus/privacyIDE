.. _code_daplug_token:

Daplug Token
~~~~~~~~~~~~

.. autoclass:: privacyidea.lib.tokens.daplugtoken.DaplugTokenClass
   :members:
   :undoc-members:
