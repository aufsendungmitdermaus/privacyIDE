.. _code_tiqr_token:

TiQR Token
~~~~~~~~~~

.. automodule:: privacyidea.lib.tokens.tiqrtoken

Implementation
..............

.. autoclass:: privacyidea.lib.tokens.tiqrtoken.TiqrTokenClass
   :members:
   :undoc-members:
