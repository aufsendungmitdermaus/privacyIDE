.. _code_totp_token:

TOTP Token
~~~~~~~~~~

.. autoclass:: privacyidea.lib.tokens.totptoken.TotpTokenClass
   :members:
   :undoc-members:
