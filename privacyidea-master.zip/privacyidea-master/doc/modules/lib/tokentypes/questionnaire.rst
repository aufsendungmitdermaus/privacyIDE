.. _code_questionnaire_token:

Questionnaire Token
~~~~~~~~~~~~~~~~~~~

.. autoclass:: privacyidea.lib.tokens.questionnairetoken.QuestionnaireTokenClass
   :members:
   :undoc-members:
