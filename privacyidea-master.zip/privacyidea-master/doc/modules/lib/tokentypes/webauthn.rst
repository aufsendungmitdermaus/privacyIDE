.. _code_webauthn_token:

WebAuthn Token
~~~~~~~~~~~~~~

.. automodule:: privacyidea.lib.tokens.webauthntoken

Implementation
..............

.. autoclass:: privacyidea.lib.tokens.webauthntoken.WebAuthnTokenClass
    :members:
    :undoc-members:
