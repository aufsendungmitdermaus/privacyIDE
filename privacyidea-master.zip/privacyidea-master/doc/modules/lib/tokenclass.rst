
Token Class
...........

The following token types are known to privacyIDEA. All are inherited from
the base tokenclass describe below.

.. toctree::
   :glob:

   tokentypes/*


.. autoclass:: privacyidea.lib.tokenclass.TokenClass
   :members:
   :undoc-members:



