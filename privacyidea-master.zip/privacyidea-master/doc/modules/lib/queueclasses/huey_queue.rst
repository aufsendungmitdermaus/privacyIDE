.. _code_huey_queue_class:

Huey Queue Class
~~~~~~~~~~~~~~~~

.. autoclass:: privacyidea.lib.queues.huey_queue.HueyQueue
   :members:
   :undoc-members:
