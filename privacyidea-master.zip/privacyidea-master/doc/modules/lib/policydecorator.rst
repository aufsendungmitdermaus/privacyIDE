
.. _policy_decorators:

Policy Decorators
.................

.. automodule:: privacyidea.lib.policydecorators
   :members:
   :undoc-members:
