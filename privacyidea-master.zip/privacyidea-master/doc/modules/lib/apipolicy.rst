.. _code_api_policy:

API Policies
............

Pre Policies
~~~~~~~~~~~~

.. automodule:: privacyidea.api.lib.prepolicy
   :members:
   :undoc-members:
   :exclude-members: current_app, g

Post Policies
~~~~~~~~~~~~~

.. automodule:: privacyidea.api.lib.postpolicy
   :members:
   :undoc-members:
   :exclude-members: current_app, g
