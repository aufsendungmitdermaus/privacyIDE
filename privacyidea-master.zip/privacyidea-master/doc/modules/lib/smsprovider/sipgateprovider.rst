.. _code_sipgate_sms_provider:

Sipgate SMS Provider
~~~~~~~~~~~~~~~~~~~~

.. autoclass:: privacyidea.lib.smsprovider.SipgateSMSProvider.SipgateSMSProvider
   :members:
   :undoc-members:
