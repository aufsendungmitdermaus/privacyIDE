.. _code_http_sms_provider:

HTTP SMS Provider
~~~~~~~~~~~~~~~~~

.. autoclass:: privacyidea.lib.smsprovider.HttpSMSProvider.HttpSMSProvider
   :members:
   :undoc-members:
