.. _code_smtp_sms_provider:

SMTP SMS Provider
~~~~~~~~~~~~~~~~~

.. autoclass:: privacyidea.lib.smsprovider.SmtpSMSProvider.SmtpSMSProvider
   :members:
   :undoc-members:
