SMS Provider
............

.. index:: SMS Provider

The following SMS providers are know to privacyIDEA

.. toctree::
   :glob:

   smsprovider/*


.. automodule:: privacyidea.lib.smsprovider
   :members:
   :undoc-members:

Base Class
~~~~~~~~~~

.. autoclass:: privacyidea.lib.smsprovider.SMSProvider.ISMSProvider
   :members:
   :undoc-members:
