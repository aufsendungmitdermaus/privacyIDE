.. _code_application_class:

Application Class
.................

.. autoclass:: privacyidea.lib.applications.MachineApplicationBase
   :members:
   :undoc-members:
