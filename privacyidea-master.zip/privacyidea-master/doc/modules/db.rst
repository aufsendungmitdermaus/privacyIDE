.. _code_db:

The database model
------------------

.. index:: database

.. automodule:: privacyidea.models
   :members:
