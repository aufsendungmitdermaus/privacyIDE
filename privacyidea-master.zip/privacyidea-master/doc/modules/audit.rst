.. _code_audit:

Audit log
---------

.. index:: audit modules

.. automodule:: privacyidea.lib.auditmodules

Base class
..........

.. autoclass:: privacyidea.lib.auditmodules.base.Audit
   :members:
   :undoc-members:


SQL Audit module
................

.. autoclass:: privacyidea.lib.auditmodules.sqlaudit.Audit
   :members:



