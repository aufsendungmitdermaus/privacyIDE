.. _code_monitoring:

Monitoring
----------

.. index:: monitoring modules

.. automodule:: privacyidea.lib.monitoringmodules

Base class
..........

.. autoclass:: privacyidea.lib.monitoringmodules.base.Monitoring
   :members:
   :undoc-members:


SQL Statistics module
.....................

.. autoclass:: privacyidea.lib.monitoringmodules.sqlstats.Monitoring
   :members:



