.. _code_pinhandler:

PinHandler
----------

.. index:: PinHandler

.. automodule:: privacyidea.lib.pinhandling.base

Base class
..........

.. autoclass:: privacyidea.lib.pinhandling.base.PinHandler
   :members:
