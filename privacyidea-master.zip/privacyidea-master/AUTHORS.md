# Authors in version 3.9

Cornelius Kölbel <cornelius.koelbel@netknights.it>
Paul Lettich <paul.lettich@netknights.it>
jona-samuel <jona-samuel.hoehmann@netknights.it>
Sebastian Lemling <sebastian@lemling.de>
pablo-knight <julio.storch@netknights.it>
Enrico M. V. Fasanelli <enrico@infn.it>
Hosted Weblate <hosted@weblate.org>
Dan Marina <dan.marina@yahoo.com>
Koen Roggemans <koen@roggemans.net>
Marco Malavolti <marco.malavolti@gmail.com>
Thierry Gaulupeau <thierry.gaulupeau@chu-nimes.fr>
Clemens Bergmann <clemens.bergmann@tu-darmstadt.de>
Lukáš Krejza <gryffus@hkfree.org>
Alex <alexander.simm@posteo.de>
Dan <denqwerta@gmail.com>
Davide Ferri <davide.ferri@aubay.it>
Felix E <felix@eckhofer.com>
Johannes Reppin <johannes.reppin@desy.de>
Marco Naimoli <marco.naimoli@gmail.com>
Maximilian Bosch <maximilian@mbosch.me>
Tanja Rolinger <tanja.rolinger@gmail.com>
sanghb <sanghb@chengda.com.cn>


# Authors in version 3.8

Cornelius Kölbel <cornelius.koelbel@netknights.it>
Paul Lettich <paul.lettich@netknights.it>
Sebastian Lemling <sebastian@lemling.de>
jona-samuel <jona-samuel.hoehmann@netknights.it>
pablo-knight <62021672+pablo-knight@users.noreply.github.com>
Salih Kiraz <salihk06@gmail.com>
Pavel Břoušek <brousek@ics.muni.cz>
EthemGit <ethem.saciak@gmail.com>
Marco Malavolti <marco.malavolti@gmail.com>
Kayhan Kaynak <kayhankaynak@gmail.com>
Koen Roggemans <koen@roggemans.net>
Salih KİRAZ <salihk06@gmail.com>
Tammo Oepkes <tammo.oepkes@suse.com>
1-am-r00t <23195315+1-am-r00t@users.noreply.github.com>
Ishdorj Idree <ishdorjidree@gmail.com>
Maximilian Allies <sir@elou.in>
Dan Marina <dan.marina@yahoo.com>
Aleksandr Sokolov <saanchos@gmail.com>
Artem <artem@molotov.work>
Bernhard M. Wiedemann <bwiedemann@suse.de>
Elouin <19814165+elouin@users.noreply.github.com>
Eric <alchemillatruth@purelymail.com>
Ethem <ethem.saciak@gmail.com>
Maximilian Bosch <maximilian@mbosch.me>
Pavel Břoušek <melanger@users.noreply.github.com>
Ryan Gelobter <ryan.g@atwgpc.net>
Ryan Gu <ryan.gu@outlook.com>
Toma Eduard <edi@lendrise.com>
hex-m <hex-m@runbox.com>


# Overall authors

Cornelius Kölbel <cornelius.koelbel@netknights.it>
Paul Lettich <paul.lettich@netknights.it>
Friedrich Weber <friedrich.weber@netknights.it>
Henning Hollermann <hollermann@physik.rwth-aachen.de>
Sebastian Lemling <sebastian@lemling.de>
Jean-Pierre <jean-pierre.hoehmann@netknights.it>
Friedrich Weber <fred@reichbier.de>
Timo Sturm <timo.sturm@netknights.it>
Henning Hollermann <laclaro@mail.com>
jona-samuel <jona-samuel.hoehmann@netknights.it>
pablo-knight <62021672+pablo-knight@users.noreply.github.com>
Cornelius Kölbel <cornelius@privacyidea.org>
Martin Wheldon <martin.wheldon@greenhills-it.co.uk>
Pavol Ipoth <pavol.ipoth@telekom.com>
Koen Roggemans <koen@roggemans.net>
Pavel Břoušek <brousek@ics.muni.cz>
jh23453 <jochen@jochen.org>
Jochen Hein <jochen@jochen.org>
Jean-Pierre Höhmann <jean-pierre.hoehmann@netknights.it>
jalr <mail@jalr.de>
yurlov-alexander <34740879+yurlov-alexander@users.noreply.github.com>
Micha Preußer <mail@mpreusser.de>
NNLemling <67051749+NNLemling@users.noreply.github.com>
NuvandaPV <jp@hhmn.de>
Salih Kiraz <salihk06@gmail.com>
dependabot[bot] <49699333+dependabot[bot]@users.noreply.github.com>
J. Lavoie <j.lavoie@net-c.ca>
Andreas Böhler <dev@aboehler.at>
Dio <diogenes.santos-de-jesus@telekom.sk>
jona-samuel <63372780+jona-samuel@users.noreply.github.com>
Jose Maria GJ <josema.gj@gmail.com>
EthemGit <ethem.saciak@gmail.com>
Jaime Zubieta <jaime.zb0@gmail.com>
Luis Gallo <gallolp@gmail.com>
Marco Malavolti <marco.malavolti@gmail.com>
Tamaro <49238587+tamaro-skaljic@users.noreply.github.com>
ToldYouThat <itoldyouthat@protonmail.com>
theo <theodor.franke@outlook.de>
Bruno <brunocascio@gmail.com>
Cornelius Kölbel <corny@cornelinux.de>
Eric <alchemillatruth@purelymail.com>
Gennady Oshnurov <gercogoge@mail.ru>
HelaBasa <R45XvezA@protonmail.ch>
Julio Storch <julio.storch@netknights.it>
Kayhan Kaynak <kayhankaynak@gmail.com>
Koen Roggemans <koen.roggemans@ritacollege.be>
Micha Preußer <micha.preusser@netknights.it>
Michael Yang <pcgames99@gmail.com>
NNLemling <sebastian@lemling.de>
Nicolas Baudrand <nbaudrand@lozere.fr>
Quoc Doan <quoc@axiadids.com>
Salih KİRAZ <salihk06@gmail.com>
Tammo Oepkes <tammo.oepkes@suse.com>
Thiago Augusto Koroll <thiagok@cloudbasis.com.br>
debianis <db91@gmx.de>
timosturm <54933730+timosturm@users.noreply.github.com>
1-am-r00t <23195315+1-am-r00t@users.noreply.github.com>
Bas van der Vlies <bas.vandervlies@surfsara.nl>
Bernd Nicklas <nicklas@hrz.uni-marburg.de>
Bruno Cascio <bruno.cascio@celerative.com>
Cody <cody@quantifiedcode.com>
Happy2C0de <46957159+Happy2C0de@users.noreply.github.com>
Ishdorj Idree <ishdorjidree@gmail.com>
Mathias Brossard <mathias@axiadids.com>
Maximilian Allies <sir@elou.in>
Nomen Nescio <info@nomennesc.io>
Omar Kohl <omarkohl@gmail.com>
Quynh Nguyen <quynh@axiadids.com>
Rodrigo Rocha <rodrigorocha.info@gmail.com>
Samuel Reed <samuel.trace.reed@gmail.com>
Sebastian Plattner <sebastian.plattner@ruag.com>
blinkiz <github@post.niklashagman.se>
cd sd <365114543@qq.com>
quoc-axiadids <quoc@axiadids.com>
yumpo55 <egor.alin@yandex.com>
Allan Nordhøy <epost@anotheragency.no>
Brendan Jurd <brendan.jurd@geoplex.com.au>
Dan Marina <dan.marina@yahoo.com>
Eric <spice2wolf@gmail.com>
Jean-Pierre Höhmann <jp@hhmn.de>
Jens-U. Mozdzen <jmozdzen@nde.ag>
Josef Wuebbels <josef.wuebbels@t-systems.com>
Konstantin Burov <sad.2.shade@gmail.com>
Lavesh Gupta <lavesh@Laveshs-MacBook-Pro.local>
M. Maraun <maraun@web.de>
Maksym Mohylko <maksym.mohylko@gmail.com>
Maria Gimenez <m.gimenez@redlink.com.ar>
Nathan <bonnemainsnathan@gmail.com>
Omoto <eomoto@santandertecnologia.com.ar>
Pascal   F u k s <pascal@foxit.pro>
Pavel Břoušek <melanger@users.noreply.github.com>
Ryan Williams <rdw@appnexus.com>
Salvo Rapisarda <sdrapisarda@gmail.com>
droobah <bananaboat@gmail.com>
koenr <koen@roggemans.net>
nicolas hahang <nicolas.hahang@gmail.com>
A <hucul@o2.pl>
Aleksandr Sokolov <saanchos@gmail.com>
AreRR <r.r.arends@hr.nl>
Artem <artem@molotov.work>
Bernhard M. Wiedemann <bwiedemann@suse.de>
Bruno <bruno.cascio@celerative.com>
Daniel Hoffend <dh@dotlan.net>
Dick Visser <dick.visser@geant.org>
Diogenes S. Jesus <splashx@users.noreply.github.com>
Dominik František Bučík <bucik@ics.muni.cz>
Elouin <19814165+elouin@users.noreply.github.com>
Ethem <ethem.saciak@gmail.com>
Fabian Cernota <cernota@chamaeleon.de>
Gallo, Luis Patricio <lugallo@santandertecnologia.com.ar>
Giacomo <gradaellig@gmail.com>
Ivan Stojmirov <stojmir@gmail.com>
Jean-Guilhem Rouel <jean-gui@w3.org>
Kleber Rocha <klinux@gmail.com>
Lavesh Gupta <lavesh@axiadids.com>
Luiz Damascena <lhfdamascena@gmail.com>
Marc Welp <m.welp@phytec.de>
Maximilian Allies <maximilian.allies@netknights.it>
Maximilian Bosch <maximilian@mbosch.me>
Michael Zhang <geekmichael@users.noreply.github.com>
Michał Borkowski <gallmkm@gmail.com>
Moritz Schlarb <moschlar@metalabs.de>
Niall Donegan <github@nialldonegan.me>
Nils Behlen <nils.behlen@netknights.it>
PhiBo <phibo@dinotools.org>
Rene Arends <renini@gmail.com>
René van Dorst <opensource@vdorst.com>
Richard Franks <git@rf152.co.uk>
Robin Gloster <mail@glob.in>
Ryan Gelobter <ryan.g@atwgpc.net>
Ryan Gu <ryan.gu@outlook.com>
Stefan Pietsch <mail.ipv4v6+gh@gmail.com>
Taylor Chase <Taylor.Chase@tempustechnologies.com>
Toma Eduard <edi@lendrise.com>
Viktor Blesak <viktor.blesak@pan-net.eu>
Voyrx <48721490+Voyrx@users.noreply.github.com>
Yannick Boursin <elipsoid@gmail.com>
blsho <38477631+blsho@users.noreply.github.com>
crlambda <lm3c@protonmail.ch>
frennkie <mail@rhab.de>
hex-m <hex-m@runbox.com>
m7four <manfred.schmid@it-schmid.com>
marcohald <marcohald@users.noreply.github.com>
markroxor <mrmohitrathoremr@gmail.com>
mjbecker <39964311+mjbecker@users.noreply.github.com>
quynh-axiadids <quynh@axiadids.com>
renini <r.r.arends@hr.nl>
root <root@Svr040.livingston.nhsscotland.com>
thisisnotacompanyaccount <18323184+thisisnotacompanyaccount@users.noreply.github.com>
whitejuly07 <whitejuly07@gmail.com>


Created using
git shortlog -sne ed39864429ca01452acb20bd1d0f340cf136bce6.. | cut -f 2,3
