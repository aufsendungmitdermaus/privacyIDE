﻿.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../Includes.txt


.. _todo:

To-Do list
==========

You can see a roadmap of privacyIDEA itself at `github`_.

Other things to do in the extension:

  * Remove the debug thing.
  * Add the possibility to test authentication.

Feel free to add any issue and feature request at `github`_.

.. _github: https://github.com/privacyidea/privacyidea
