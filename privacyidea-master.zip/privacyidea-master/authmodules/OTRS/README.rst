This repository has moved here:

https://github.com/privacyidea/otrs

