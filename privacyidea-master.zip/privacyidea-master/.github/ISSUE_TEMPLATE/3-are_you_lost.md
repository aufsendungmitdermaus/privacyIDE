---
name: Are you lost?
about: If you did not find a bug and do not want to suggest a new feature, you probably have some questions.
title: ''
labels: 'Tye: Question'
assignees: ''

---

To address general questions about the usage of privacyIDEA, we run a distinct forum, where you can discuss your problems in regards to installation, setup or configuration.
Please go to: https://community.privacyidea.org.

The github issues are not meant for such questions.
If you still think, that you encountered an issue, that needs a fix or change in the code, you are welcome to file an issue!
