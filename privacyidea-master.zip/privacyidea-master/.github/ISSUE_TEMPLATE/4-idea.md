---
name: Idea
about: Suggest an idea for this project
title: ''
labels: 'Type: Idea!'
assignees: ''

---

**What kind of unspecific general idea do you have?**

This is ment for a very generic idea. 
That does not yet have any technical depth.
If you have a more concrete request and also have some technical thoughts,
please open a "Feature Request".
