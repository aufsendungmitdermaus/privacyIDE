"""v3.8: Merging revisions

Revision ID: d3c0f0403a84
Revises: ('fabcf24d9304', 'a28f2733897b')
Create Date: 2022-11-30 22:37:19.986083

"""

# revision identifiers, used by Alembic.
revision = 'd3c0f0403a84'
down_revision = ('fabcf24d9304', 'a28f2733897b')

from alembic import op
import sqlalchemy as sa


def upgrade():
    pass


def downgrade():
    pass
